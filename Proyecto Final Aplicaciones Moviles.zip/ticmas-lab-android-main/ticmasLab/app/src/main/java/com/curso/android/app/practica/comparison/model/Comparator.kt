package com.curso.android.app.practica.comparison.model

import java.util.Date

data class Comparator(val number: Int, val timestamp: Date)




